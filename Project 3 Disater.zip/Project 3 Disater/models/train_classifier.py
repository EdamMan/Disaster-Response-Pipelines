import sys
import re
import pickle
import pandas as pd
import numpy as np
import nltk
nltk.download(['punkt', 'wordnet' , 'stopwords', 'averaged_perceptron_tagger' ])
from sqlalchemy import create_engine
from nltk import word_tokenize,sent_tokenize
from nltk import pos_tag
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from sklearn.tree import DecisionTreeClassifier
from sklearn.pipeline import Pipeline,FeatureUnion
from sklearn.multioutput import MultiOutputClassifier
from sklearn.metrics import classification_report
from sklearn.base import BaseEstimator,TransformerMixin
from sklearn.preprocessing import FunctionTransformer
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.ensemble import RandomForestClassifier, AdaBoostClassifier
from sklearn.feature_extraction.text import CountVectorizer, TfidfTransformer,TfidfVectorizer

def load_data(database_filepath):
    '''
    load data from database
    input:
    - database filepath
    output:
    - X text column
    - Y target classification
    - category_names
    '''
    engine = create_engine('sqlite:///InsertDatabaseName.db')
    df = pd.read_sql_table('InsertTableName', engine)
    X = df['message']
    Y = df.iloc[:, 4:]
    category_names = df.columns[4:]
    
    print(X)
    print(Y)
    
    return X, Y, category_names

def tokenize(text):
    '''
    a tokenization function to process text data as a part of ML pipeline
    input:
    - text file
    output:
    - a post-processed list of words
    '''
    stop_word=stopwords.words('english')
    text=re.sub(r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+',' ',text)
    text=re.sub(r'[^0-9A-Za-z]',' ',text)
   
    tokens=word_tokenize(text)
    lemmatizer=WordNetLemmatizer()
    
   
    tokens_data=[]
    for i in tokens:
        if i not in stop_word:
            clean_token=lemmatizer.lemmatize(i).lower().strip()
            
            clean_token=lemmatizer.lemmatize(clean_token,pos='v')
            tokens_data.append(clean_token)
    return tokens_data

def build_model():
    '''
    function to bulid a ml Pipeline
    no input
    output:
    - model classifier
    '''
    pipeline = Pipeline([
        ('vect', CountVectorizer(tokenizer=tokenize)),
        ('tfidf', TfidfTransformer()),
        ('clf', MultiOutputClassifier(RandomForestClassifier()))
    ])
    
    parameters = {'clf__estimator__n_estimators': [5, 10]}
    # grid search object
    cv = GridSearchCV(pipeline, param_grid=parameters)
    return cv

def evaluate_model(model, X_test, Y_test, category_names):
    '''
    function to report  f1 score, precision and recall for each output category of the dataset
    input:
    - model trained classifier
    - X_test
    - Y_test
    - category_names
    output:
    - detailed evaluation of each categories
    '''
    Y_pred = model.predict(X_test)
    # reporting the f1 score, precision and recall
    for i in range(len(category_names)):
        print('Category: "', category_names[i], '"')
        print(classification_report(Y_test.iloc[:, 1].values, Y_pred[:, i]))
     
    accuracy = (Y_pred == Y_test).mean().mean()
    print('Accuracy: ', accuracy)

def save_model(model, model_filepath):
    '''
    function to save the finalized model
    input:
    - model trained classifier
    - model_filepath
    '''
    pickle.dump(model, open('new_model.pkl', "wb"))


def main():
    if len(sys.argv) == 3:
        database_filepath, model_filepath = sys.argv[1:]
        print('Loading data...\n    DATABASE: {}'.format(database_filepath))
        X, Y, category_names = load_data(database_filepath)
        X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.2)

        print('Building model...')
        model = build_model()

        print('Training model...')
        model.fit(X_train, Y_train)

        print('Evaluating model...')
        evaluate_model(model, X_test, Y_test, category_names)

        print('Saving model...\n    MODEL: {}'.format(model_filepath))
        save_model(model, model_filepath)

        print('Trained model saved!')

    else:
        print('Please provide the filepath of the disaster messages database '\
              'as the first argument and the filepath of the pickle file to '\
              'save the model to as the second argument. \n\nExample: python '\
              'train_classifier.py ../data/DisasterResponse.db classifier.pkl')


if __name__ == '__main__':
    main()
